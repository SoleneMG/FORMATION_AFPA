package darman.part2;

public class Exo2_01 {
	/**
	 * Variables val, double num�riques D�but 
	 * Val <-- 231 
	 * Double <-- Val * 2 
	 * Ecrire Val 
	 * Ecrire Double 
	 * Fin
	 * 
	 */

	public static void main(String[] args) {
		double val = 231;
		double d = val * 2;
		System.out.println("val = "+ val);
		System.out.println("double = "+ d);
	}

}
