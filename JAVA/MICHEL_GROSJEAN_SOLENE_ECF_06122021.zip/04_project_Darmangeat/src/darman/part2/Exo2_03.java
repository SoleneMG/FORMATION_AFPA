package darman.part2;

import java.util.Scanner;

public class Exo2_03 {
	public static Scanner sc = new Scanner(System.in);
	
	/**
		Ecrire un programme qui demande son pr�nom � l'utilisateur, et qui lui r�ponde par un charmant � Bonjour � suivi du pr�nom. 
		On aura ainsi le dialogue suivant :
		machine : Quel est votre pr�nom ?
		utilisateur : Marie-Cun�gonde
		machine : Bonjour, Marie Cun�gonde !
	 * 
	 */
	
public static void main(String[] args) {
	
		System.out.println("Quel est votre pr�nom ?");
		String firstName = sc.nextLine();
		System.out.println("Bonjour, "+firstName+" !");
		
		sc.close();
	}


}
