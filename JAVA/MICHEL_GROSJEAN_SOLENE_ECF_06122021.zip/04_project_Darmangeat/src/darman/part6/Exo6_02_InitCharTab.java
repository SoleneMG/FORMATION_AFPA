package darman.part6;



public class Exo6_02_InitCharTab {


	/**
	 * Ecrire un algorithme qui d�clare et remplisse un tableau contenant les six voyelles de l�alphabet latin.
	 */

	public static void main(String[] args) {
		
		char[] board = {'a','e','i','o','u','y'};	
		System.out.printf("Il y a %d valeurs dans le tableau.", board.length);
	}

}
