package darman.part3;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Exo3_06Test {
	
	/**
	 * if (age > 12) {
			System.out.println("Tu fais partie des Cadets !");
		} else if (age > 9 && age < 12) {
			System.out.println("Tu fais partie des Minimes !");
		} else if (age > 7 && age < 10) {
			System.out.println("Tu fais partie des Pupilles !");
		} else if (age > 5 && age < 8) {
			System.out.println("Tu fais partie des Poussins !");
		} else {
			System.out.println("Tu ne fais partie d'aucune cat�gorie !");
		}
	 */

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
