
public class Item1_Short {
/**
 * Ecrire une application dans laquelle une instruction for effectue 40_000 it�rations avec un compteur de type short. Justifier le dysfonctionnement.
 */
	
	public static void main(String[] args) {
		
		System.out.println(Short.MAX_VALUE);
		/*
		 * for (short i = 0; i < 40_000; i++) { System.out.println(i); }
		 */
	}
}
