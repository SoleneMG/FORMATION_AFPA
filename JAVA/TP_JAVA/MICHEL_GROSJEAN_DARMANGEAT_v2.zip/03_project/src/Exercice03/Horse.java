package Exercice03;
public class Horse {
    public final String name;

    public Horse(String name){
        this.name = name;
    }
    
}
