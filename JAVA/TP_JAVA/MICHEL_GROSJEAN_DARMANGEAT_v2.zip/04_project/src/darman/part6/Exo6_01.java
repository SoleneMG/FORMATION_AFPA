package darman.part6;



public class Exo6_01 {


	/**
	 * Ecrire un algorithme qui d�clare et remplisse un tableau de 7 valeurs
	 * num�riques en les mettant toutes � z�ro.
	 */

	public static void main(String[] args) {
		
		int[] board = {0,0,0,0,0,0,0};	
		System.out.printf("Il y a %d valeurs dans le tableau.", board.length);
	}

}
