package darman.part8;

public class Exo8_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
