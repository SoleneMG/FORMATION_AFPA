package ventou.test;

import ventou.metier.Commercial;
import ventou.metier.Cv;
import ventou.metier.Salarie;

/* Mise en oeuvre d'une association 1-1 bi-directionnelle*/
public class TestCv {

	public static void main( String [] args ) {
	
	System.out.println ("CREATION De PLUSIEURS CV ");
	System.out.println( "------------------------\n");
	
	//TODO
	
	System.out.println ("CREATION De PLUSIEURS TYPE DE SALARIES ");
	System.out.println( "--------------------------------------\n");
	
	//TODO
	
	System.out.println ("affectez les CV à différents types de salariés");
	System.out.println( "---------------------------------------------\n");
	
	//TODO
	
	System.out.println ("Affichez tous les salariés");
	System.out.println( "-------------------------\n");
	
	//TODO
	
	}
}