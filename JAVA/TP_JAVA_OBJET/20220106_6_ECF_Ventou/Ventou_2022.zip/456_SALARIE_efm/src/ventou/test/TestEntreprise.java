package ventou.test;
import ventou.metier.*;
/* Mise en oeuvre d'une association */
public class TestEntreprise {
public static void main( String [] args ) {

	System.out.println ("CREATION De PLUSIEURS CV ");
	System.out.println( "------------------------\n");
	
	//TODO

		
	System.out.println ("CREATION De PLUSIEURS TYPE DE SALARIES ");
	System.out.println( "--------------------------------------\n");
	
	//TODO

	
	System.out.println ("CREATION D'UNE ENTREPRISE ");
	System.out.println( "-------------------------\n");
	
	//TODO

	
	System.out.println ("affectez les CV à différents types de salariés");
	System.out.println( "---------------------------------------------\n");
	
	//TODO


	System.out.println ("affectez les salariés à l'entreprise");
	System.out.println( "------------------------------------\n");
	
	//TODO

	System.out.println ("Affichez les informations sur l'entreprise");
	System.out.println( "-------------------------\n");
	
	//TODO
}}