package achat.metier;

public class AchatException extends Exception {
private static final long serialVersionUID = 1L;

public AchatException(String message) {
	super(message);
}
public AchatException() {
	super("Probl�me g�n�rique sur l'applicatif des achats");
}
public static void main(String[] args) {
	System.out.println(new AchatException("C'est trop cher !"));
	System.out.println(new AchatException());
}}
