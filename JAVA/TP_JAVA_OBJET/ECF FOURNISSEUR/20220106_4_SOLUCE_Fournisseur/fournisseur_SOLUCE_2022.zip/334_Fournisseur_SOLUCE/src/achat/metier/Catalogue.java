package achat.metier;

import java.util.ArrayList;

public class Catalogue {

	private int noCatalogue;
	private ArrayList<Produit> produits = new ArrayList<>();

	public Catalogue(int noCatalogue) {
		this.noCatalogue = noCatalogue;
	}

	public Catalogue() {
		this(0);
	}

	public int getNoCatalogue() {
		return noCatalogue;
	}

	public void setNoCatalogue(int noCatalogue) {
		this.noCatalogue = noCatalogue;
	}

	public void addProduit(Produit prod) {
		this.produits.add(prod);
	}

	public void nbProduit() {
		this.produits.size();
	}

	public float getPrixProduitTotal() {
		float total = 0;
		for (Produit prod : this.produits) {
			total += prod.getPrixUnit();
		}
		return total;
	}

	@Override
	public String toString() {
		return "Catalogue : Num�ro Catalogue= " + noCatalogue + ".";
	}

	public static void main(String[] args) {
	}

}
