package achat.metier;

public class Fournisseur implements Cloneable, Comparable<Fournisseur> {

private String nom;
private float totalAchat; // Montant total des Achats
private int noAgr; // num�ro d'agr�ment
private Catalogue catalogue;

private static int idxAgr = 1001;
///////////////////////////////
// Constructeurs
public Fournisseur(String nom, int no) {
	this.nom = nom;
	totalAchat = 0;
	this.noAgr = no;
}
public Fournisseur(String nom) {
	this(nom, idxAgr++);
//		this.nom = nom;
//		totalAchat = 0;
//		noAgr = idxAgr++;
}
public Fournisseur() {
	this("ANONYME");
//		this.nom = "ANONYME";
//		totalAchat = 0;
//		noAgr = idxAgr++;
}
protected void init() {
	totalAchat = 0;
}
/////////////////////////////////
// Getters / Setters
public String getNom() {return nom;}
public void setNom(String nom) {this.nom = nom;}
public int getNoAgr() {return noAgr;}
public void setNoAgr(int noAgr) {this.noAgr = noAgr;}

public Catalogue getCatalogue() {
	return catalogue;
}
public void setCatalogue(Catalogue catalogue) {
	this.catalogue = catalogue;
}

public float getTotalAchat() {
	return totalAchat;
}
public void setTotalAchat(float totalAchat) {
	this.totalAchat = totalAchat;
}
//RG1
public void addAchat(float montant) throws AchatException {
	if (montant >= 0) {
		totalAchat += montant;
	} else {
		throw new AchatException("Le montant d'un achat doit �tre positif.");
	}
}

public float getPrixCatalogue() {
	return this.catalogue.getPrixProduitTotal();
}

@Override public String toString() {
	return "Fournisseur : Nom= " + nom + ", Num�ro d'Agr�ment= " + noAgr + ", Total des Achats= " + totalAchat
			+ "�. Catalogue nunm�ro : "
			+ (this.catalogue != null ? this.catalogue.getNoCatalogue() : "pas de catalogue.");
}

@Override public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((nom == null) ? 0 : nom.hashCode());
	return result;
}

@Override public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Fournisseur other = (Fournisseur) obj;
	if (nom == null) {
		if (other.nom != null)
			return false;
	} else if (!nom.equals(other.nom))
		return false;
	return true;
}

//passer � public la m�thode clone
@Override public Object clone() {
	try {
		Fournisseur cloned = (Fournisseur) super.clone();
		cloned.totalAchat = 0;
		return cloned;
	} catch (CloneNotSupportedException e) {
		throw new RuntimeException("Echec � la cr�ation du clone" , e);
	}
}
//
//@Override public Fournisseur clone() {
//return new Fournisseur(nom,noAgr);
//}	
@Override public int compareTo(Fournisseur f) {
	return this.totalAchat < f.getTotalAchat() ? -1 : (this.totalAchat > f.getTotalAchat() ? 1 : 0);
}
//@Override public int compareTo(Fournisseur f) {
//	return (int)(this.getTotalAchat()-f.getTotalAchat());
//}

public void bonus() {}

// Tests
public static void main(String[] args) throws AchatException {
	System.out.println("\tTest des constructeurs :");
	System.out.println(new Fournisseur("HomeOffice", 1500));
	System.out.println(new Fournisseur("HomeDepot"));
	System.out.println(new Fournisseur());

	System.out.println("\n\tTest Equals :");
	Fournisseur f1 = new Fournisseur("Toto", 1854);
	f1.addAchat(250);
	Fournisseur f2 = new Fournisseur("Toto", 2957);
	Fournisseur f3 = new Fournisseur("Alfred");
	System.out.println("Autre fournisseurs :\n" + f1 + "\n" + f2 + "\n" + f3 +"\n");
	System.out.println("Toto (1854) = Toto (2957) : " + f1.equals(f2));
	System.out.println("Toto (1854) = Alfred : " + f1.equals(f3));

	System.out.println("\n\tClone du Nom et N� agr�ment :");
	Fournisseur f4 = (Fournisseur) f1.clone();
	System.out.println("Original :" + f1 + "  // hascode : " + f1.hashCode());
	System.out.println("Original :" + f4 + "  // hascode : " + f4.hashCode());

	System.out.println("\n\tCompareTo :");
	f2.addAchat(319);
	f3.addAchat(57);
	f4.addAchat(319);
	System.out.println("f1= " + f1);
	System.out.println("f2= " + f2);
	System.out.println("f3= " + f3);
	System.out.println("f4= " + f4);
	System.out.println("Comparaison f1 et f2 : " + f1.compareTo(f2));
	System.out.println("Comparaison f2 et f3 : " + f2.compareTo(f3));
	System.out.println("Comparaison f2 et f4 : " + f2.compareTo(f4));
}}
