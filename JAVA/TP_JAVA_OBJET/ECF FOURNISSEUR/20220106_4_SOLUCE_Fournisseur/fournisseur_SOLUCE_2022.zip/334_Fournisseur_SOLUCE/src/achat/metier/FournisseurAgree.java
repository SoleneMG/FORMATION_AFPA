package achat.metier;

public class FournisseurAgree extends Fournisseur{

	public FournisseurAgree(String nom, int noAgr){
		super(nom, noAgr);
	}
	public FournisseurAgree(String nom){
		super(nom);
	}
	private FournisseurAgree(){
		super();
	}
	@Override
	public String toString() {
		return "FournisseurAgree [getNom()=" + getNom() + ", getNoAgr()=" + getNoAgr() + ", getCatalogue()="
				+ getCatalogue() + ", getTotalAchat()=" + getTotalAchat() + ", getPrixCatalogue()=" + getPrixCatalogue()
				+ ", toString()=" + super.toString() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ "]";
	}
}
