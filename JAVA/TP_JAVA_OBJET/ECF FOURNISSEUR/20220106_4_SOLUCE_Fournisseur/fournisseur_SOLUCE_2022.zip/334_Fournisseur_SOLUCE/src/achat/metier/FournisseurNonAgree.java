package achat.metier;

public class FournisseurNonAgree extends Fournisseur {

	private float totalAchatMax;

//	public FournisseurNonAgree(String nom, int no, float totalAchatMax) {
//		super( nom , 0);
//		this.setTotalAchatMax(totalAchatMax);
//	}
//		setNom(nom);
//		setNoAgr(0);
//this.totalAchatMax = totalAchatMax;

	public FournisseurNonAgree(String nom, float totalAchatMax) {
		super( nom , 0);
		this.setTotalAchatMax(totalAchatMax);
//		setNom(nom);
//		setNoAgr(0);
//		this.totalAchatMax = totalAchatMax;
	}

	public FournisseurNonAgree() {
		this("ANONYME" , 0);
//		setNom("Anonyme");
//		setNoAgr(0);
	}

	public float getTotalAchatMax() {
		return totalAchatMax;
	}

	public void setTotalAchatMax(float totalAchatMax) {
		this.totalAchatMax = totalAchatMax;
	}

	@Override
	public void addAchat(float montant) throws AchatException {
		//RG2
		if ((this.getTotalAchat() + montant) > this.totalAchatMax) {
			throw new AchatException("Le montant d�passe la limite d'achat.");
		} else {
			//RG1
			super.addAchat(montant);
		}
	}

	@Override
	public String toString() {
		return " Fournisseur Non Agree : Total des Achats Max= " + totalAchatMax + "�." + super.toString();
	}
	@Override
	public void bonus() {
		float augment=(10*totalAchatMax/100);
		this.totalAchatMax=this.totalAchatMax+augment;
	}	
	public static void main(String[] args) {
	}

}
