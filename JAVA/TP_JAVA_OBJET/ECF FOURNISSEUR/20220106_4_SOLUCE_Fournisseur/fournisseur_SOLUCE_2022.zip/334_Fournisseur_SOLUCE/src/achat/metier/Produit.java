package achat.metier;

public class Produit {

	private String idProduit;
	private String designation;
	private float prixUnit;

	public Produit(String idProduit, String designation, float prixUnit) {
		this.idProduit = idProduit;
		this.designation = designation;
		this.prixUnit = prixUnit;
	}

	public Produit(String idProduit) {
		this(idProduit, "Vide", 0);
	}

	public Produit() {
		this("Inconnu", "Vide", 0);
	}

	public String getIdProduit() {
		return idProduit;
	}

	public void setIdProduit(String idProduit) {
		this.idProduit = idProduit;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public float getPrixUnit() {
		return prixUnit;
	}

	public void setPrixUnit(float prixUnit) {
		this.prixUnit = prixUnit;
	}

	@Override
	public String toString() {
		return "Produit : Identifiant Produit= " + idProduit + ", D�signation= " + designation + ", Prix Unitaire = "
				+ prixUnit + "�.";
	}

	public static void main(String[] args) {
		
	}

}
