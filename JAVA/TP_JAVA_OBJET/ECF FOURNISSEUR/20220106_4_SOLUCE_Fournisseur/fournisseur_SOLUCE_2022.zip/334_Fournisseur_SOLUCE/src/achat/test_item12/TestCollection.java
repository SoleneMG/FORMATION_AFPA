package achat.test_item12;
import achat.metier.*;
import java.util.*;

public class TestCollection {

	public static void main(String args[]) 
	{
		LinkedList<Fournisseur> fournisseurs = new LinkedList<>();
		fournisseurs.add (new Fournisseur ("sun"));
		fournisseurs.add (new Fournisseur ("ibm"));
		fournisseurs.add (new FournisseurNonAgree ("Microsoft", 1000));
		fournisseurs.add (new FournisseurNonAgree ("Symantec", 2000));
		System.out.println();
		System.out.println("les fournisseurs");
		System.out.println("-------------------------");
		for (Fournisseur four : fournisseurs) {
			System.out.println(four);
		}
		System.out.println();
		
		for (int n=0; n<15; n++) {
			System.out.println("achat de 100E à tous les fournisseurs");
			for (int i=0; i<fournisseurs.size(); i++) {
				Fournisseur rf = (Fournisseur )fournisseurs.get(i);
				
				try {
					rf.addAchat(100);
				}
				catch (AchatException e) {
					System.out.println( "Pour le fournisseur :" + rf.getNom() + "   Exception levee :" + e );
				}
			}
		}
		
		System.out.println();
		System.out.println( "Le contenu de la collection :");
		
		for (int i=0; i<fournisseurs.size(); i++)
			System.out.println((Fournisseur )fournisseurs.get(i));
	}
}
