package achat.test_item14_TODO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import achat.metier.Fournisseur;
import achat.metier.FournisseurNonAgree;
/*les fournisseurs tri�s  par la valeur du  � montant total des achats �
(ordre de tri ascendant (croissant))*/

/*les fournisseurs tri�s  par la valeur du  � montant total des achats �
avec un ordre de tri descendant */
public class TestCollectionTri {
public static void main(String[] args) {

	List<Fournisseur> fournisseurs = new ArrayList<>();
	Fournisseur fc1 = new Fournisseur("fc1");
	fc1.setTotalAchat(236);
	fournisseurs.add(fc1);
	Fournisseur fc2 = new Fournisseur("fc2");
	fc2.setTotalAchat(520);
	fournisseurs.add(fc2);
	Fournisseur fc3 = new Fournisseur("fc3");
	fc3.setTotalAchat(850);
	fournisseurs.add(fc3);
	FournisseurNonAgree fna1 = new FournisseurNonAgree("fna1", 1500);
	fna1.setTotalAchat(560);
	fournisseurs.add(fna1);
	FournisseurNonAgree fna2 = new FournisseurNonAgree("fna2", 1500);
	fna2.setTotalAchat(286);
	fournisseurs.add(fna2);
	FournisseurNonAgree fna3 = new FournisseurNonAgree("fna3", 1500);
	fna3.setTotalAchat(57);
	fournisseurs.add(fna3);
	System.out.println();
	System.out.println("les fournisseurs");
	System.out.println("-------------------------");
	for (Fournisseur four : fournisseurs) {
		System.out.println(four);
	}
	System.out.println();
	System.out.println("affichez les fournisseurs tri�s  par la valeur du  � montant total des achats �");
	System.out.println("(ordre de tri ascendant (croissant))");
	System.out.println("-------------------------------------------------------------------------------");
	Collections.sort(fournisseurs);
	for (Fournisseur four : fournisseurs) {
		System.out.println(four);
	}
	//Collections.reverse(fournisseurs);
	System.out.println();
	System.out.println("les fournisseurs tri�s  par la valeur du  � montant total des achats �");
	System.out.println("avec un ordre de tri descendant  (d�croissant)");
	System.out.println("----------------------------------------------------------------------");
	Collections.sort(fournisseurs, Collections.reverseOrder());
	for (Fournisseur four : fournisseurs) {
		System.out.println(four);
	}
}}
