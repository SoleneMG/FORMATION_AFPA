package achat.test_item17_TODO;

import achat.metier.Catalogue;
import achat.metier.Fournisseur;
import achat.metier.Produit;

public class TestPrixCatalogue {
public static void main(String[] args) {
	
	Produit p1=new Produit("id1","armoire",250);
	Produit p2=new Produit("id2","bureau",175);
	Produit p3=new Produit("id3","poubelle",5);
	System.out.println("\nListe des produits:");
	System.out.println("--------------------");
	System.out.println(p1);
	System.out.println(p2);
	System.out.println(p3);		
	System.out.println();
	
	Catalogue catalogue = new Catalogue(425);
	catalogue.addProduit(p1); catalogue.addProduit(p2); catalogue.addProduit(p3);
	
	Fournisseur ikea = new Fournisseur("IKEA");
	ikea.setCatalogue(catalogue);
	System.out.println(ikea);
	System.out.println();

	System.out.println("Le prix du catalogue IKEA: "+ikea.getPrixCatalogue()+"�");
}}
