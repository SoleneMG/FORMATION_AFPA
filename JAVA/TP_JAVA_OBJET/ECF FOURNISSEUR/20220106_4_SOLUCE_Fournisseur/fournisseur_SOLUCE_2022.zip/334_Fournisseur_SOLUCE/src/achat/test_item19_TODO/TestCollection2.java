package achat.test_item19_TODO;

import java.util.LinkedList;

import achat.metier.AchatException;
import achat.metier.Catalogue;
import achat.metier.Fournisseur;
import achat.metier.FournisseurAgree;
import achat.metier.FournisseurNonAgree;
import achat.metier.Produit;

public class TestCollection2 {

	public static void main(String args[]) 
	{
		LinkedList<Fournisseur> fournisseurs = new LinkedList<Fournisseur>();
		Produit p1=new Produit("id1","armoire",100);
		Produit p2=new Produit("id2","bureau",170);
		Catalogue catalogue = new Catalogue(335);
		catalogue.addProduit(p1);
		catalogue.addProduit(p2);

		FournisseurAgree fa1=new FournisseurAgree ("sun");
		FournisseurAgree fa2=new FournisseurAgree ("ibm");
		FournisseurNonAgree fna3=new FournisseurNonAgree ("Microsoft", 1000);
		FournisseurNonAgree fna4=new FournisseurNonAgree ("Symantec", 2000);
		
		fa1.setCatalogue(catalogue);
		fa2.setCatalogue(catalogue);
		fna3.setCatalogue(catalogue);
		fna4.setCatalogue(catalogue);
		
		fournisseurs.add (fa1);
		fournisseurs.add (fa2);
		fournisseurs.add (fna3);
		fournisseurs.add (fna4);
		System.out.println();
		System.out.println("les fournisseurs");
		System.out.println("-----------------");

		for (int i=0; i<fournisseurs.size(); i++) {
			System.out.println(fournisseurs.get(i));
		}

		System.out.println();
		System.out.println("Un bonus pour les fournisseurs");
		System.out.println("-----------------------------");
		for (int i=0; i<fournisseurs.size(); i++) {
			fournisseurs.get(i).bonus();
			System.out.println(fournisseurs.get(i));
		}
		System.out.println();

		//Test achat n�gatif:	
		try {
			fournisseurs.get(0).addAchat(-10);
		}
		catch (AchatException e) {
			System.out.println( "Exception levee :" + e );
		}
		System.out.println();
	
		for (int n=0; n<15; n++) {
			for (int i=0; i<fournisseurs.size(); i++) {
				Fournisseur rf = fournisseurs.get(i);
				try {
					rf.addAchat(100);
				}
				catch (AchatException e) {
					System.out.println( "Exception levee :" + e );
				}
			}
		}
		
		System.out.println();
		System.out.println( "Le contenu de la collection :");
		
		for (int i=0; i<fournisseurs.size(); i++)
			System.out.println((Fournisseur )fournisseurs.get(i));
	}
}
