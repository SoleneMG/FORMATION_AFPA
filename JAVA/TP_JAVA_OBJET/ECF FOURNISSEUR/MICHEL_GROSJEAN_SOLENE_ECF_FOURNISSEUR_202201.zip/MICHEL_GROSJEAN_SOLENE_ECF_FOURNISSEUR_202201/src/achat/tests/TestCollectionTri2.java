package achat.tests;

public class TestCollectionTri2 {
	public static void main(String[] args) {
		/*les fournisseurs triés  par la valeur du  « montant total des achats »
		avec un ordre de tri descendant */
		// TODO 
		// TODO 
		// TODO 
	}

}
