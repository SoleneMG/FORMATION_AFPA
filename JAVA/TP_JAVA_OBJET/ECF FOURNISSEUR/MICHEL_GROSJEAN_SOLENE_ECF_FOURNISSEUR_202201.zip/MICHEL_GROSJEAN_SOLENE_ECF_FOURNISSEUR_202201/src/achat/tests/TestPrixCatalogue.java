package achat.tests;

public class TestPrixCatalogue {

	public static void main(String[] args) {
		// TODO
		// TODO
		// TODO
	}
}
