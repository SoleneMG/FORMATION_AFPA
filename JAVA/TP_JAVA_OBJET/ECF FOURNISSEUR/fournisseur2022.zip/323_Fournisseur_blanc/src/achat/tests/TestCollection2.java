package achat.tests;

public class TestCollection2 {

	public static void main(String[] args) {
		// TODO
		// TODO
		// TODO

	}
}
