package achat.tests;

public class TestCollectionTri {
	public static void main(String[] args) {
		
		/*les fournisseurs triés  par la valeur du  « montant total des achats »
		  (ordre de tri ascendant (croissant))*/
		
		// TODO 
		// TODO 
		// TODO 
	}

}
