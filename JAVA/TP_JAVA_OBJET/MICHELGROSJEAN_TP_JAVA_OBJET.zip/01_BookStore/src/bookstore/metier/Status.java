package bookstore.metier;

public enum Status {
	PRETE,
	DISPONIBLE,
	SUPPRIME;
}
