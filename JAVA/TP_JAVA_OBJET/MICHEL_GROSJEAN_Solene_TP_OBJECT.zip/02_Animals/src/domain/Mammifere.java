package domain;

public class Mammifere extends Animal{

	public Mammifere(String nom) {
		super(nom);
	}
	
	

}
